//
//  War_Card_GameApp.swift
//  War Card Game
//
//  Created by ARUN S S on 08/08/23.
//

import SwiftUI

@main
struct War_Card_GameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
